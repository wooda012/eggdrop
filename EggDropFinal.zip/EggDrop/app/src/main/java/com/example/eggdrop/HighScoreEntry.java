package com.example.eggdrop;

public class HighScoreEntry {

    double score;
    String name;

    public HighScoreEntry(){
        score = 0;
        name = "None";
    }
    public HighScoreEntry(double newScore, String newName){
        score = newScore;
        name = newName;
    }

    public String getName(){
        return name;
    }

    public double getScore(){
        return score;
    }

    public void setName(String newName){
        name = newName;
    }

    public void setScore(double newScore){
        score = newScore;
    }

}
