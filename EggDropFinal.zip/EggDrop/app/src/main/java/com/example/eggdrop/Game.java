package com.example.eggdrop;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class Game extends Activity {

    GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN); //fullscreens game screen
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Intent fromMain =getIntent();
        String username =fromMain.getStringExtra("username");
        gameView = new GameView(this, username); //instead of xml we load GameView
        setContentView(gameView);

    }

    @Override
    protected void onStart() {
        super.onStart();
        gameView.start(); //starts game
    }

    @Override
    protected void onStop() {
        super.onStop();
        gameView.stop(); //stops listeners
        gameView.stopOBST();
    }
}
