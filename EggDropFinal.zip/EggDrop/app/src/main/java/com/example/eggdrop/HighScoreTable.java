package com.example.eggdrop;


import java.util.ArrayList;

public class HighScoreTable {

    ArrayList<HighScoreEntry> scoreTable;

    public HighScoreTable(){
        scoreTable = new ArrayList<HighScoreEntry>(11);
        for (int i=0; i<10; i++)
            scoreTable.add(new HighScoreEntry());
    }

    public HighScoreEntry getEntry(int pos){
        return scoreTable.get(pos-1);
    }

    public void addScore(HighScoreEntry newEntry){
        for(int i = 0; i < 10; i++){
            if(newEntry.getScore() >= scoreTable.get(i).getScore()){
                scoreTable.add(i,newEntry);
                scoreTable.remove(10);
                break;
            }
        }
    }
    public void clear(){
        scoreTable.clear();
        for (int i=0; i<10; i++)
            scoreTable.add(i,new HighScoreEntry());
    }
}
