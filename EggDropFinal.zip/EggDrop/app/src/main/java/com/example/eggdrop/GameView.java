package com.example.eggdrop;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.view.SurfaceView;
import android.view.SurfaceHolder;

import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, SensorEventListener {


    public String userName; //retain this from main menu and send to hiscores
    private MainThread thread;

    private Egg pEgg; //static objects that will always exist in game
    private Cloud cloudOne;
    private Cloud cloudTwo;

    private SensorManager sensorManager;
    private Sensor sensor; //sensor for accelerometer data, used for tilt + device shake
    private float tilt;
    private float xAccel; //device shake variables
    private float yAccel;
    private float zAccel;
    private float xPreviousAccel;
    private float yPreviousAccel;
    private float zPreviousAccel;
    private boolean firstUpdate = true;
    private final float shakeThreshold = 6f;
    private boolean shakeInitiated = false;
    private Context mContext;

    //these objects are the obstacles that will be created and destroyed at various times during the run
    private AvoidObst AV1;
    private AvoidObst AV2;
    private ShakeObst SH;
    private ShakeObst NOB;
    private Boolean colDet;
    //handlers for running the object creation threads
    private Handler lHandler; //left avoid obst handler
    private Handler rHandler; //right avoid obst handler
    private Handler sHandler; //shake obst handler
    private Handler nHandler;
    private Handler audioHandler;

    //audio detection thread
    private int audioThreshold = 6;
    private DetectNoise mSensor;
    private Runnable detAudio = new Runnable() {
        public void run() {
            double amp = mSensor.getAmplitude();
            if ((amp > audioThreshold)) {
                if(NOB != null){ //if there is a noise object on screen, delete it
                    NOB = null;
                }
            }
            audioHandler.postDelayed(detAudio, 200); //every 200ms checks amp of audio in
        }
    };

    Random rand = new Random(); //random is used to add variance in obstacle timing
    int rInt;
    int rSpeed;
    Runnable leftObst = new Runnable() { //this handles the creation of the left avoid obstacle
        @Override
        public void run() {
            try {
                rInt = rand.nextInt(2000) + 2000;
                rSpeed = rand.nextInt(15) + 30;
                if(AV2 == null) { //if there is no right avoid obstacle on screen, then go ahead and create a left one
                    AV1 = new AvoidObst(BitmapFactory.decodeResource(getResources(), R.drawable.obstbmp), 50, rSpeed);
                }else if(AV2.getY() < 1050){ //if there is a right obstacle but it is far enough up the screen to not create an impossible situtation, then create a left one
                    AV1 = new AvoidObst(BitmapFactory.decodeResource(getResources(), R.drawable.obstbmp), 50, rSpeed);
                }
                else{
                    rInt = 300; //if there is a right obstacle that is too close for us to create a left obstacle, check again in 300ms
                }
            } finally {
                lHandler.postDelayed(leftObst, rInt);
            }
        }
    };
    Runnable rightObst = new Runnable() { //same function as the left obstacle but checks left obstacle before creation
        @Override
        public void run() {
            try {
                rInt = rand.nextInt(2000) + 2000;
                rSpeed = rand.nextInt(15) + 30;
                if(AV1 == null) {
                    AV2 = new AvoidObst(BitmapFactory.decodeResource(getResources(), R.drawable.obstbmp), 750, rSpeed);
                }else if(AV1.getY() < 1050){
                    AV2 = new AvoidObst(BitmapFactory.decodeResource(getResources(), R.drawable.obstbmp), 750, rSpeed);
                }
                else{
                    rInt = 300;
                }
            } finally {
                rHandler.postDelayed(rightObst, rInt);
            }
        }
    };
    Runnable shakeObst = new Runnable() { //this handles creation of the shake obstacle
        @Override
        public void run() {
            try {
                rInt = rand.nextInt(4000) + 4000;
                rSpeed = rand.nextInt(15) + 20;
                if(SH == null) { //checks to make sure a shake obstacle doesnt already exist
                    SH = new ShakeObst(BitmapFactory.decodeResource(getResources(), R.drawable.shakeobstbmp), rSpeed);
                }
                else{
                    rInt = 300; //if a shake obstacle exists, check again in 300ms
                }
            } finally {
                sHandler.postDelayed(shakeObst, rInt);
            }
        }
    };
    Runnable noiseObst = new Runnable() { //this handles creation of the noise obstacle (same code as shake obstacle with dif. timing)
        @Override
        public void run() {
            try {
                rInt = rand.nextInt(3000) + 7000;
                rSpeed = rand.nextInt(15) + 20;
                if(NOB == null) {
                    NOB = new ShakeObst(BitmapFactory.decodeResource(getResources(), R.drawable.noiseobstbmp), rSpeed);
                }
                else{
                    rInt = 300;
                }
            } finally {
                nHandler.postDelayed(noiseObst, rInt);
            }
        }
    };


    public GameView(Context context, String user) {
        super(context);
        getHolder().addCallback(this);
        mContext = context;
        userName = user;
        colDet = false;
        mSensor = new DetectNoise();
        sensorManager = (SensorManager) mContext.getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); //getting the accelerometer from the device
        thread = new MainThread(getHolder(), this); //init main thread
        setFocusable(true);
    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) { //on creation of the canvas, we start the main thread and create some objects
        thread.setRunning(true);
        thread.start();
        pEgg = new Egg(BitmapFactory.decodeResource(getResources(),R.drawable.eggbmp)); //player egg
        cloudOne = new Cloud(BitmapFactory.decodeResource(getResources(),R.drawable.cloudbmp),100, -1); //background clouds
        cloudTwo = new Cloud(BitmapFactory.decodeResource(getResources(),R.drawable.cloudbmp),500, 800);
        lHandler = new Handler(); //init creation handlers
        rHandler = new Handler();
        sHandler = new Handler();
        nHandler = new Handler();
        audioHandler = new Handler();
        detAudio.run(); //begin running audio detection
        startOBST(); //start the obstacle creation threads
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                thread.setRunning(false);
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            retry = false;
        }
    }
    public void update() {
        pEgg.update(tilt); //update the egg's position
        cloudOne.update(); //update clouds position
        cloudTwo.update();
        if(AV1 != null){ //if the left obstacle exists, updates position and checks for collision
            AV1.update();
            if((pEgg.getX()+ 250) - AV1.getX() >= 0 & (AV1.getX() + 500) - pEgg.getX() >= 0){
                if(450 - AV1.getY() >= 0 & AV1.getY() >= 0) {
                    colDet = true;
                }
            }
            if(AV1.getY() < -600){ //checks if the obstacle is off screen (has been dodged by player)
                AV1 = null;
            }
        }
        if(AV2 != null){//if the right obstacle exists, updates position and checks for collision
            AV2.update();
            if((pEgg.getX()+ 250) - AV2.getX() >= 0 & (AV2.getX() + 500) - pEgg.getX() >= 0){
                if(450 - AV2.getY() >= 0 & AV2.getY() >= 0) {
                    colDet = true;
                }
            }
            if(AV2.getY() < -600){//checks if the obstacle is off screen (has been dodged by player)
                AV2 = null;
            }
        }
        if(SH != null){ //if the shake obstacle exists, updates position and checks for collision
            SH.update();
            if(SH.getY() < 600){
                colDet = true;
            }
        }
        if(NOB != null){ //if the noise obstacle exists, updates position and checks for collision
            NOB.update();
            if(NOB.getY() < 600){
                colDet = true;
            }
        }
    }
    @Override
    public void draw(Canvas canvas) { //draws all objects on the screen, called every frame to update positions
        super.draw(canvas);
        if (canvas != null) {
            canvas.drawColor(Color.CYAN);
            cloudOne.draw(canvas);
            cloudTwo.draw(canvas);
            if(AV1 != null){
                AV1.draw(canvas);
            }
            if(AV2 != null){
                AV2.draw(canvas);
            }
            if(SH != null){
                SH.draw(canvas);
            }
            if(NOB != null){
                NOB.draw(canvas);
            }
            pEgg.draw(canvas);
        }
    }
    @Override
    public void onSensorChanged(SensorEvent event) { //runs when accelerometer data changes
        tilt = -event.values[0]; //grabs tilt value to use in player egg control

        updateAccelParameters(event.values[0], event.values[1], event.values[2]);   //updates accelerometer data for device shake detection
        if ((!shakeInitiated) && isAccelerationChanged()) {        //makes sure we dont overwrite initial shake data
            shakeInitiated = true;
        } else if ((shakeInitiated) && isAccelerationChanged()) {     //this means device was shaken, deletes a shake obstacle if it exists
            if(SH != null){
                SH = null;
            }
        } else if ((shakeInitiated) && (!isAccelerationChanged())) {       //if device doesnt detect a shake it resets the detector
            shakeInitiated = false;
        }
    }
    private void updateAccelParameters(float xNewAccel, float yNewAccel, float zNewAccel) {
        if (firstUpdate) {
            xPreviousAccel = xNewAccel;
            yPreviousAccel = yNewAccel;
            zPreviousAccel = zNewAccel;
            firstUpdate = false;
        } else {
            xPreviousAccel = xAccel;
            yPreviousAccel = yAccel;
            zPreviousAccel = zAccel;
        }
        xAccel = xNewAccel;
        yAccel = yNewAccel;
        zAccel = zNewAccel;
    }
    private boolean isAccelerationChanged() {
        float deltaX = Math.abs(xPreviousAccel - xAccel);
        float deltaY = Math.abs(yPreviousAccel - yAccel);
        float deltaZ = Math.abs(zPreviousAccel - zAccel);
        return (deltaX > shakeThreshold && deltaY > shakeThreshold) || (deltaX > shakeThreshold && deltaZ > shakeThreshold) || (deltaY > shakeThreshold && deltaZ > shakeThreshold);
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
    public void start() {
        sensorManager.registerListener(this, sensor, 10000);
        mSensor.start();
    }
    public void stop() {
        sensorManager.unregisterListener(this);
        audioHandler.removeCallbacks(detAudio);
        mSensor.stop();
    }

    public void startOBST(){
        leftObst.run();
        rightObst.run();
        sHandler.postDelayed(shakeObst, 4000);
        nHandler.postDelayed(noiseObst,7000);
    }
    public void stopOBST(){
        lHandler.removeCallbacks(leftObst);
        rHandler.removeCallbacks(rightObst);
        sHandler.removeCallbacks(shakeObst);
        nHandler.removeCallbacks(noiseObst);
    }
    public Boolean detCol(){
        return colDet;
    }

}
