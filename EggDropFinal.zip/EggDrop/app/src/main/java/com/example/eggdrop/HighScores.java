package com.example.eggdrop;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class HighScores extends AppCompatActivity {

    HighScoreTable table;
    String newUsername;
    String endScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_scores);

        table = new HighScoreTable();
        if(!fileExists(this,"HighScores.txt")){ //checks to see if a highscore file exists and inits if it is not.
            String fileName = "HighScores.txt";
            String content = "None 0 \nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0";
            FileOutputStream outputStream = null;
            try {
                outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
                outputStream.write(content.getBytes());
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Scanner scan = null;
        try { //opens the highscore file
            scan = new Scanner(openFileInput("HighScores.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while (scan.hasNextLine()) { //reads in highscores from file
            String line =scan.nextLine();
            String name;
            String scoreString;
            StringTokenizer tokenizer = new StringTokenizer(line);
            name = tokenizer.nextToken();
            scoreString = tokenizer.nextToken();
            double scoreDouble = Double.parseDouble(scoreString);
            table.addScore(new HighScoreEntry(scoreDouble, name));
        }
        scan.close();

        Intent intent =getIntent();
        newUsername =intent.getStringExtra("username");
        String endScore = intent.getStringExtra("score");
        double newScore = Double.valueOf(endScore);
        if(!newUsername.equals("-1TEST")){ //checks if we actually have a new highscore to add, or if we are just going to highscore menu from main menu without playing
            table.addScore(new HighScoreEntry(newScore, newUsername)); //adds new highscore to highscore file and rewrites it
            deleteFile("HighScores.txt");
            PrintStream output = null;
            try {
                output = new PrintStream(openFileOutput("HighScores.txt", Context.MODE_PRIVATE));
                for(int i =1; i <= 10; i++){
                    String line = table.getEntry(i).getName() + " " + table.getEntry(i).getScore();
                    output.println(line);
                }
                output.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            new AlertDialog.Builder(this).setTitle("The Egg Broke!").setMessage("Final Score: " + endScore).show();
        }
        fillTextViews();
    }
    public void fillTextViews(){ //fills the textviews on screen with highscores
        TextView name1 = (TextView)findViewById(R.id.name1);
        TextView name2 = (TextView)findViewById(R.id.name2);
        TextView name3 = (TextView)findViewById(R.id.name3);
        TextView name4 = (TextView)findViewById(R.id.name4);
        TextView name5 = (TextView)findViewById(R.id.name5);
        TextView name6 = (TextView)findViewById(R.id.name6);
        TextView name7 = (TextView)findViewById(R.id.name7);
        TextView name8 = (TextView)findViewById(R.id.name8);
        TextView name9 = (TextView)findViewById(R.id.name9);
        TextView name10 = (TextView)findViewById(R.id.name10);
        TextView score1 = (TextView)findViewById(R.id.score1);
        TextView score2 = (TextView)findViewById(R.id.score2);
        TextView score3 = (TextView)findViewById(R.id.score3);
        TextView score4 = (TextView)findViewById(R.id.score4);
        TextView score5 = (TextView)findViewById(R.id.score5);
        TextView score6 = (TextView)findViewById(R.id.score6);
        TextView score7 = (TextView)findViewById(R.id.score7);
        TextView score8 = (TextView)findViewById(R.id.score8);
        TextView score9 = (TextView)findViewById(R.id.score9);
        TextView score10 = (TextView)findViewById(R.id.score10);

        name1.setText(table.getEntry(1).getName());
        name2.setText(table.getEntry(2).getName());
        name3.setText(table.getEntry(3).getName());
        name4.setText(table.getEntry(4).getName());
        name5.setText(table.getEntry(5).getName());
        name6.setText(table.getEntry(6).getName());
        name7.setText(table.getEntry(7).getName());
        name8.setText(table.getEntry(8).getName());
        name9.setText(table.getEntry(9).getName());
        name10.setText(table.getEntry(10).getName());
        score1.setText(String.valueOf(table.getEntry(1).getScore()));
        score2.setText(String.valueOf(table.getEntry(2).getScore()));
        score3.setText(String.valueOf(table.getEntry(3).getScore()));
        score4.setText(String.valueOf(table.getEntry(4).getScore()));
        score5.setText(String.valueOf(table.getEntry(5).getScore()));
        score6.setText(String.valueOf(table.getEntry(6).getScore()));
        score7.setText(String.valueOf(table.getEntry(7).getScore()));
        score8.setText(String.valueOf(table.getEntry(8).getScore()));
        score9.setText(String.valueOf(table.getEntry(9).getScore()));
        score10.setText(String.valueOf(table.getEntry(10).getScore()));

    }

    public void goToMainMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("username", newUsername);
        startActivity(intent);
    }

    public boolean fileExists(Context context, String filename) {
        File file = context.getFileStreamPath(filename);
        if(file == null || !file.exists()) {
            return false;
        }
        return true;
    }

    public void clearHighScores(View view) {
        deleteFile("HighScores.txt");
        String fileName = "HighScores.txt";
        String content = "None 0 \nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0\nNone 0";
        FileOutputStream outputStream = null;
        try {
            outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write(content.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        table.clear();
        fillTextViews();
    }
}
