package com.example.eggdrop;

import android.content.Intent;
import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class MainThread extends Thread {
    private SurfaceHolder surfaceHolder;
    private GameView gameView;
    private boolean running;
    public static Canvas canvas;
    private int targetFPS = 60;
    private double averageFPS;
    long runStartTime;

    public MainThread(SurfaceHolder surfaceHolder, GameView gameView) {

        super();
        this.surfaceHolder = surfaceHolder;
        this.gameView = gameView;
        runStartTime = System.currentTimeMillis();
    }

    @Override
    public void run() {
        long startTime;
        long timeMillis;
        long waitTime;
        long totalTime = 0;
        int frameCount = 0;
        long targetTime = 1000 / targetFPS;

        while (running) {
            startTime = System.nanoTime();
            canvas = null;
            try {
                canvas = this.surfaceHolder.lockCanvas();
                synchronized(surfaceHolder) {
                    this.gameView.update();
                    if(gameView.detCol()){
                        running = false;
                    }
                    this.gameView.draw(canvas);
                }
            } catch (Exception e) {       }
            finally {
                if (canvas != null)            {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            timeMillis = (System.nanoTime() - startTime) / 1000000;
            waitTime = targetTime - timeMillis; //if we are running faster than target fps slow the thread down

            try {
                this.sleep(waitTime);
            } catch (Exception e) {}

            totalTime += System.nanoTime() - startTime;
            frameCount++;
            if (frameCount == targetFPS)        {
                averageFPS = 1000 / ((totalTime / frameCount) / 1000000);
                frameCount = 0;
                totalTime = 0;
                System.out.println(averageFPS);
            }
        }
        //this occurs when a collision is detected in the game, sends username and score to highscores screen and stops listeners
        if(!running & gameView.detCol()){
            long millis = System.currentTimeMillis() - runStartTime;
            int seconds = (int) (millis / 1000);
            String millisFormatted = String.format("%03d", millis % 1000);
            String scoreText = seconds + "." + millisFormatted;
            Intent intent = new Intent(gameView.getContext(), HighScores.class);
            intent.putExtra("username", gameView.userName);
            intent.putExtra("score", scoreText);
            gameView.stop();
            gameView.stopOBST();
            gameView.getContext().startActivity(intent);
        }

    }

    public void setRunning(boolean isRunning) {
        running = isRunning;
    }

}
